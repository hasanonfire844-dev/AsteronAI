# Asteron AI

Grok-powered chat UI + Express backend (`server.js`).

## Setup

```bash
npm install
export GROK_API_KEY=xai-your-key   # or put in .env and use dotenv
npm start
```

Open http://localhost:3000

## API (server.js)

| Route | Method | Body | Notes |
|-------|--------|------|--------|
| `/api/chat` | POST | `{ messages: [...] }` | Grok chat completions |
| `/api/image` | POST | `{ prompt: "..." }` | Grok image generation |
| `/api/voice-token` | POST | — | Browser speech only |
| `/api/video` | POST | — | Not connected yet |

API key stays on the server only (`process.env.GROK_API_KEY`). Never put it in the HTML.

## GitHub / Render / Railway

1. Push this folder (include `index.html`, `server.js`, `package.json`).
2. Set env var `GROK_API_KEY`.
3. Start command: `node server.js` (or `npm start`).
